package com.sample.numtoword.conversion;

import org.junit.Test;

public class NumberToWordConversionTest {
	
	 @Test
	 public void testNumberToWord() throws Exception {
		 NumberToWordConversion numTOWordConversion = new NumberToWordConversion();
		 numTOWordConversion.printWord(23, " ");
	 }
	 
	 
	 @Test
	 public void testNumberToWord_Decimal() throws Exception {
		 NumberToWordConversion numTOWordConversion = new NumberToWordConversion();
		 numTOWordConversion.printWord(5, " ");
	 }
	 
	 @Test
	 public void testNumberToWord_Zero() throws Exception {
		 NumberToWordConversion numTOWordConversion = new NumberToWordConversion();
		 numTOWordConversion.printWord(0, " ");
	 }

}
