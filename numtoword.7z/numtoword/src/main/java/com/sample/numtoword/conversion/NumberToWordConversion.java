package com.sample.numtoword.conversion;

import java.util.Scanner;

public class NumberToWordConversion {

	/*
	 * API to check if a number is containing how many digits
	 * 
	 * Given a number 
	 * When printWord API is called 
	 * Then return void
	 */
	public void printWord(int n, String ch) throws Exception {
		try {
			String one[] = { " ", " one", " two", " three", " four", " five", " six", " seven", " eight", " Nine",
					" ten", " eleven", " twelve", " thirteen", " fourteen", "fifteen", " sixteen", " seventeen",
					" eighteen", " nineteen" };

			String ten[] = { " ", " ", " twenty", " thirty", " forty", " fifty", " sixty", "seventy", " eighty",
					" ninety" };

			if (n < 0) {
				System.out.println("Enter a positive number");
			}
			if (n > 19) {
				System.out.print(ten[n / 10] + " " + one[n % 10]);
			} else {
				System.out.print(one[n]);
			}
			if (n > 0)
				System.out.print(ch);
		} catch (NumberFormatException e) {
			e.printStackTrace();
		}

	}

	public static void main(String[] args) throws Exception {
		int n = 0;
		@SuppressWarnings("resource")
		Scanner scanf = new Scanner(System.in);
		System.out.println("Enter an integer number: ");
		n = scanf.nextInt();

		if (n <= 0) {
			System.out.println("Enter numbers greater than 0");
		} else {
				convertNumToWord(n);

		}
	}

	/*
	 * API to print a word for the equivalent number
	 * 
	 * Given a number 
	 * When printWord API is called 
	 * Then return void
	 */
	private static void convertNumToWord(int n) throws Exception {
		NumberToWordConversion numToWordConversion = new  NumberToWordConversion();
		numToWordConversion.printWord((n / 10000000) % 100, " crore");
		numToWordConversion.printWord(((n / 100000) % 100), " lakh");
		numToWordConversion.printWord(((n / 1000) % 100), " thousand");
		numToWordConversion.printWord(((n / 100) % 10), " hundred");
		numToWordConversion.printWord((n % 100), " ");
	}
}
